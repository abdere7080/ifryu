import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import { eq } from 'drizzle-orm';
import { db } from './db';
import { users } from '@shared/schema';
import session from 'express-session';
import connectPgSimple from 'connect-pg-simple';
import { pool } from './db';
import type { Request, Response, NextFunction, Express } from 'express';

// يتطلب الملف البيئي
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
const SESSION_SECRET = process.env.SESSION_SECRET || 'chataro-secret-key';

const PgSession = connectPgSimple(session);

// Function to set up authentication middleware
export function setupAuth(app: Express) {
  // إعداد جلسة المستخدم
  app.use(
    session({
      store: new PgSession({
        pool,
        tableName: 'sessions',
        createTableIfMissing: true,
      }),
      secret: SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === 'production',
        maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      },
    })
  );

  // إعداد Passport
  app.use(passport.initialize());
  app.use(passport.session());

  // حفظ واسترجاع جلسة المستخدم
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await db.select().from(users).where(eq(users.id, id)).limit(1);
      done(null, user[0] || null);
    } catch (error) {
      done(error, null);
    }
  });

  // إعداد استراتيجية Google OAuth
  if (GOOGLE_CLIENT_ID && GOOGLE_CLIENT_SECRET) {
    passport.use(
      new GoogleStrategy(
        {
          clientID: GOOGLE_CLIENT_ID,
          clientSecret: GOOGLE_CLIENT_SECRET,
          callbackURL: '/auth/google/callback',
          scope: ['email', 'profile'],
        },
        async (accessToken, refreshToken, profile, done) => {
          try {
            // البحث عن المستخدم بواسطة معرف Google
            const existingUsers = await db
              .select()
              .from(users)
              .where(eq(users.id, profile.id))
              .limit(1);

            const existingUser = existingUsers[0];

            if (existingUser) {
              // تحديث بيانات المستخدم إذا لزم الأمر
              return done(null, existingUser);
            }

            // إنشاء مستخدم جديد إذا لم يكن موجودًا
            const email = profile.emails && profile.emails[0]?.value;
            
            if (!email) {
              return done(new Error('لم يتم العثور على بريد إلكتروني من Google'), null);
            }

            const [newUser] = await db
              .insert(users)
              .values({
                id: profile.id,
                email: email,
                name: profile.displayName,
                profileImageUrl: profile.photos?.[0]?.value,
                provider: 'google',
                emailVerified: true,
              })
              .returning();

            return done(null, newUser);
          } catch (error) {
            return done(error, null);
          }
        }
      )
    );
  } else {
    console.warn('تنبيه: لم يتم تكوين Google OAuth. المصادقة باستخدام Google غير متاحة.');
  }

  // إضافة طرق المصادقة
  app.get('/auth/google', passport.authenticate('google'));
  app.get(
    '/auth/google/callback',
    passport.authenticate('google', {
      successRedirect: '/',
      failureRedirect: '/login',
    })
  );

  // تسجيل الخروج
  app.get('/auth/logout', (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ error: 'حدث خطأ أثناء تسجيل الخروج' });
      }
      res.redirect('/');
    });
  });

  // واجهة برمجة التطبيقات للحصول على معلومات المستخدم الحالي
  app.get('/api/user', (req, res) => {
    if (req.isAuthenticated()) {
      const user = req.user as typeof users.$inferSelect;
      // إخفاء البيانات الحساسة
      const safeUser = {
        id: user.id,
        email: user.email,
        name: user.name,
        profileImageUrl: user.profileImageUrl,
      };
      return res.json(safeUser);
    }
    return res.json(null);
  });
}

// وظيفة وسيطة للتحقق مما إذا كان المستخدم مصادقًا
export function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  return res.status(401).json({ error: 'غير مصرح به' });
}