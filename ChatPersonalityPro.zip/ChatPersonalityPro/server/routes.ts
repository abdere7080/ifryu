import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import { extractTextFromImage } from "./ocr";
import { analyzePersonality } from "./openai";
import { imageUploadSchema } from "@shared/schema";
import { z } from "zod";
import { setupAuth, isAuthenticated } from "./auth";

const inMemoryStorage = multer.memoryStorage();
const upload = multer({ 
  storage: inMemoryStorage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // إعداد نظام المصادقة
  setupAuth(app);

  // واجهة برمجة التطبيقات لتحليل صور الدردشة
  app.post("/api/analyze", async (req, res) => {
    try {
      console.log("Received analyze request");
      
      // Validate request
      const { images } = imageUploadSchema.parse(req.body);
      
      if (!images || images.length === 0) {
        console.log("No images provided in request");
        return res.status(400).json({ message: "No images provided" });
      }
      
      console.log(`Processing ${images.length} images for OCR extraction`);
      
      // إستخراج النص من جميع الصور باستخدام OCR
      const extractedTextPromises = images.map(async (image, index) => {
        try {
          console.log(`Processing image ${index + 1}/${images.length}`);
          // Check if the image is in correct data URL format 
          if (!image.includes('base64,')) {
            console.log(`Image ${index + 1} is not in correct data URL format`);
            return "";
          }
          
          console.log(`Sending complete data URL for image ${index + 1} to OCR.Space API`);
          
          // Send the complete data URL (OCR.Space API expects the full format)
          return await extractTextFromImage(image);
        } catch (err) {
          console.error(`Error processing image ${index + 1}:`, err);
          return ""; // Return empty string for failed images
        }
      });
      
      const extractedTexts = await Promise.all(extractedTextPromises);
      console.log("All images processed, combining extracted text");
      
      // Filter out empty strings
      const validTexts = extractedTexts.filter(text => text.trim() !== "");
      
      if (validTexts.length === 0) {
        console.log("No text could be extracted from any of the images");
        return res.status(400).json({ message: "Could not extract any text from the provided images" });
      }
      
      const combinedText = validTexts.join("\n\n--- Next Screenshot ---\n\n");
      
      // تحليل النص المستخرج باستخدام GPT-4
      const analysisResult = await analyzePersonality(combinedText);
      
      // حفظ نتائج التحليل في قاعدة البيانات إذا كان المستخدم مسجل دخول
      if (req.isAuthenticated() && req.user) {
        const userId = (req.user as any).id;
        try {
          await storage.createAnalysis({
            userId,
            extractedText: combinedText,
            result: analysisResult
          });
        } catch (saveError) {
          console.error("Error saving analysis to database:", saveError);
          // استمر في العملية حتى إذا فشل الحفظ
        }
      }
      
      // إرجاع نتائج التحليل
      return res.status(200).json(analysisResult);
    } catch (error) {
      console.error("Error analyzing chat:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid request data", 
          errors: error.errors 
        });
      }
      
      return res.status(500).json({ 
        message: "Failed to analyze chat",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // واجهة برمجة التطبيقات للحصول على سجل التحليلات السابقة للمستخدم
  app.get("/api/analyses", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const analyses = await storage.getAnalysesByUser(userId);
      return res.status(200).json(analyses);
    } catch (error) {
      console.error("Error fetching analyses:", error);
      return res.status(500).json({ 
        message: "Failed to fetch analyses",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Download endpoint for project zip
  app.get('/download/project', (req, res) => {
    const file = 'chataro-project.zip';
    res.download(file, 'chataro-project.zip', (err) => {
      if (err) {
        console.error('Download error:', err);
        res.status(404).send('File not found');
      }
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
