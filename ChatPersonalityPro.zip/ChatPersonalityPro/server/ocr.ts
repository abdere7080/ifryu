import axios from "axios";
import FormData from "form-data";

// The OCR.Space API endpoint
const OCR_API_URL = "https://api.ocr.space/parse/image";
const OCR_API_KEY = process.env.OCR_API_KEY || "K89234980288957";

interface OcrResponse {
  ParsedResults: Array<{
    ParsedText: string;
    ErrorMessage: string;
    ErrorDetails: string;
  }>;
  OCRExitCode: number;
  IsErroredOnProcessing: boolean;
  ErrorMessage: string | null;
  ProcessingTimeInMilliseconds: string;
}

/**
 * Extracts text from an image using OCR.Space API
 * @param dataUrl Complete data URL with prefix (data:image/jpeg;base64,...)
 */
export async function extractTextFromImage(dataUrl: string): Promise<string> {
  try {
    console.log("Starting OCR processing...");
    
    // OCR.Space API expects the full data URL format
    const formData = new FormData();
    formData.append("apikey", OCR_API_KEY);
    formData.append("base64Image", dataUrl); // Send the complete data URL
    formData.append("language", "eng");
    formData.append("detectOrientation", "true");
    formData.append("scale", "true");
    formData.append("OCREngine", "2");
    
    console.log("Sending OCR request with complete data URL...");
    
    const response = await axios.post(OCR_API_URL, formData, {
      headers: {
        ...formData.getHeaders(),
      },
    });
    
    const data = response.data as OcrResponse;
    
    // Check for errors
    if (data.IsErroredOnProcessing || data.OCRExitCode !== 1) {
      console.error("OCR API returned an error:", data.ErrorMessage);
      throw new Error(data.ErrorMessage || "OCR processing failed");
    }
    
    // Process results
    const extractedText = data.ParsedResults
      .map((result) => result.ParsedText)
      .join("\n")
      .trim();
    
    if (!extractedText) {
      console.log("Warning: No text was extracted from the image");
      return "";
    }
    
    console.log("OCR extraction successful");
    return extractedText;
    
  } catch (error) {
    console.error("OCR processing failed:", error);
    
    if (axios.isAxiosError(error)) {
      console.error("OCR API response status:", error.response?.status);
      console.error("OCR API response details:", error.response?.data);
      throw new Error(`OCR API Error: ${error.response?.data?.ErrorMessage || error.message}`);
    } else {
      throw new Error(`OCR Error: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }
}
