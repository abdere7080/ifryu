import { GoogleGenerativeAI } from "@google/generative-ai";
import Groq from "groq-sdk";
import type { PersonalityAnalysis } from "@shared/schema";

// Initialize Google Generative AI with Gemini (primary)
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// Initialize Groq as backup (only if API key is available)
let groq: Groq | null = null;
if (process.env.GROQ_API_KEY) {
  groq = new Groq({
    apiKey: process.env.GROQ_API_KEY,
  });
}

const analysisPrompt = `You are a personality analyst expert who can determine personality traits from chat conversations. 
Analyze the provided chat messages to identify personality traits, communication patterns, strengths, and areas of growth.

Provide a detailed analysis structured in the following JSON format (respond with valid JSON only):
{
  "summary": "A paragraph summarizing the personality profile based on the chat messages",
  "communicationStyle": "Brief description of communication style (2-3 words)",
  "decisionMaking": "Brief description of decision-making approach (2-3 words)",
  "socialApproach": "Brief description of social approach (2-3 words)",
  "emotionalExpression": "Brief description of emotional expression (2-3 words)",
  "traits": [
    {"name": "Extraversion", "value": 85, "color": "hsl(142, 76%, 36%)"},
    {"name": "Agreeableness", "value": 62, "color": "hsl(217, 91%, 60%)"},
    {"name": "Conscientiousness", "value": 70, "color": "hsl(47, 96%, 53%)"},
    {"name": "Emotional Stability", "value": 78, "color": "hsl(280, 59%, 65%)"},
    {"name": "Openness", "value": 90, "color": "hsl(24, 95%, 53%)"}
  ],
  "communicationPatterns": [
    {"title": "Communication Pattern 1", "description": "Detailed description of communication pattern"},
    {"title": "Communication Pattern 2", "description": "Detailed description of communication pattern"}
  ],
  "strengths": ["Strength 1", "Strength 2", "Strength 3", "Strength 4"],
  "growthAreas": ["Growth area 1", "Growth area 2", "Growth area 3", "Growth area 4"],
  "compatibilityInsights": "A paragraph about compatibility with other personality types",
  "worksWellWith": ["Personality Type 1", "Personality Type 2", "Personality Type 3"],
  "challengesWith": ["Personality Type 1", "Personality Type 2", "Personality Type 3"]
}

The analysis should be based solely on the content of the chat. Do not make up information and be as specific as possible. Use neutral language.`;

async function analyzeWithGroq(text: string): Promise<PersonalityAnalysis> {
  if (!groq) {
    throw new Error("Groq backup service is not available - API key not provided");
  }
  
  console.log("Using Groq backup service...");
  
  const completion = await groq.chat.completions.create({
    model: "llama-3.1-70b-versatile",
    messages: [
      {
        role: "system",
        content: analysisPrompt
      },
      {
        role: "user",
        content: `Chat messages to analyze:\n${text}`
      }
    ],
    temperature: 0.7,
    max_tokens: 2000,
  });

  const analysisText = completion.choices[0]?.message?.content;
  
  if (!analysisText) {
    throw new Error("Empty response from Groq");
  }

  // Clean up the response to extract JSON
  let cleanedText = analysisText.trim();
  
  // Remove markdown code blocks if present
  if (cleanedText.startsWith('```json')) {
    cleanedText = cleanedText.replace(/^```json\s*/, '').replace(/\s*```$/, '');
  } else if (cleanedText.startsWith('```')) {
    cleanedText = cleanedText.replace(/^```\s*/, '').replace(/\s*```$/, '');
  }
  
  const analysis = JSON.parse(cleanedText) as PersonalityAnalysis;
  return analysis;
}

export async function analyzePersonality(text: string): Promise<PersonalityAnalysis> {
  try {
    console.log("Starting personality analysis with Gemini...");
    
    const prompt = `${analysisPrompt}
    
    Chat messages to analyze:
    ${text}`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const analysisText = response.text();
    
    if (!analysisText) {
      throw new Error("Empty response from Gemini");
    }
    
    console.log("Gemini analysis completed successfully");
    
    // Clean up the response to extract JSON
    let cleanedText = analysisText.trim();
    
    // Remove markdown code blocks if present
    if (cleanedText.startsWith('```json')) {
      cleanedText = cleanedText.replace(/^```json\s*/, '').replace(/\s*```$/, '');
    } else if (cleanedText.startsWith('```')) {
      cleanedText = cleanedText.replace(/^```\s*/, '').replace(/\s*```$/, '');
    }
    
    const analysis = JSON.parse(cleanedText) as PersonalityAnalysis;
    return analysis;
  } catch (error) {
    console.error("Gemini analysis failed, trying Groq backup:", error);
    
    // Try Groq as backup if available
    if (groq) {
      try {
        return await analyzeWithGroq(text);
      } catch (groqError) {
        console.error("Both Gemini and Groq failed:", groqError);
        throw new Error(`Failed to analyze personality with both services: Gemini - ${error instanceof Error ? error.message : "Unknown error"}, Groq - ${groqError instanceof Error ? groqError.message : "Unknown error"}`);
      }
    } else {
      console.error("Groq backup not available, no API key provided");
      throw new Error(`Failed to analyze personality: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }
}
