import { useState, useEffect, useCallback } from 'react';
import { Language } from '@/i18n';

export function useLanguage() {
  // Try to get the language from localStorage, defaulting to 'en'
  const [language, setLanguage] = useState<Language>(() => {
    const savedLanguage = localStorage.getItem('language') as Language;
    const validLanguages: Language[] = ['en', 'ar', 'fr', 'es', 'ja'];
    return validLanguages.includes(savedLanguage) ? savedLanguage : 'en';
  });

  useEffect(() => {
    // Save language preference to localStorage whenever it changes
    localStorage.setItem('language', language);
    
    // Set the document direction based on language
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
    
    // Force page re-render by updating a CSS custom property
    document.documentElement.style.setProperty('--current-language', language);
    
    // Trigger a custom event to notify components of language change
    window.dispatchEvent(new CustomEvent('languageChange', { detail: { language } }));
  }, [language]);

  const toggleLanguage = useCallback(() => {
    setLanguage(prevLang => prevLang === 'en' ? 'ar' : 'en');
  }, []);

  const changeLanguage = useCallback((newLang: Language) => {
    if (newLang !== language) {
      setLanguage(newLang);
      // Force a small delay to ensure state updates properly
      setTimeout(() => {
        window.location.reload();
      }, 100);
    }
  }, [language]);

  return {
    language,
    toggleLanguage,
    changeLanguage,
    isRtl: language === 'ar'
  };
}
