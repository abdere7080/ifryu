import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";

export interface AuthUser {
  id: string;
  email: string;
  name: string | null;
  profileImageUrl: string | null;
}

export function useAuth() {
  const { 
    data: user,
    isLoading,
    error,
    refetch
  } = useQuery<AuthUser | null>({
    queryKey: ['/api/user'],
    queryFn: getQueryFn({ on401: "returnNull" }),
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  const isAuthenticated = !!user;

  return {
    user,
    isLoading,
    isAuthenticated,
    error,
    refetch
  };
}