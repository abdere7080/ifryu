import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { getTranslation } from '@/i18n';
import type { Language } from '@/i18n';
import type { PersonalityAnalysis } from '@shared/schema';
import html2canvas from 'html2canvas';

export function useAnalysis(language: Language) {
  const [ocrProgress, setOcrProgress] = useState(0);
  const [aiProgress, setAiProgress] = useState(0);
  const [analysisResult, setAnalysisResult] = useState<PersonalityAnalysis | null>(null);
  const { toast } = useToast();

  // Simulated progress updates - in a real app, you might get these from server events
  const startProgressSimulation = () => {
    setOcrProgress(0);
    setAiProgress(0);
    
    // Simulate OCR progress
    const ocrInterval = setInterval(() => {
      setOcrProgress(prev => {
        const next = prev + Math.random() * 5;
        if (next >= 100) {
          clearInterval(ocrInterval);
          return 100;
        }
        return next;
      });
    }, 100);
    
    // Start AI progress after OCR reaches ~40%
    setTimeout(() => {
      const aiInterval = setInterval(() => {
        setAiProgress(prev => {
          const next = prev + Math.random() * 3;
          if (next >= 100) {
            clearInterval(aiInterval);
            return 100;
          }
          return next;
        });
      }, 150);
    }, 2000);
  };

  // Analyze mutation
  const analyzeMutation = useMutation({
    mutationFn: async (images: string[]) => {
      startProgressSimulation();
      
      const response = await apiRequest('POST', '/api/analyze', { images });
      return response.json();
    },
    onSuccess: (data: PersonalityAnalysis) => {
      setAnalysisResult(data);
      
      // Force progress to 100% when done
      setOcrProgress(100);
      setAiProgress(100);
    },
    onError: (error) => {
      toast({
        title: getTranslation(language, 'errors.analysisFailed'),
        description: error.message,
        variant: 'destructive'
      });
      
      // Reset progress
      setOcrProgress(0);
      setAiProgress(0);
    }
  });

  // Copy results to clipboard
  const copyResultsToClipboard = async () => {
    if (!analysisResult) return;
    
    try {
      // Create a text representation of the analysis
      const textResult = `
        Personality Analysis Results
        
        Personality Summary
        ${analysisResult.summary}
        
        Communication Style: ${analysisResult.communicationStyle}
        Decision Making: ${analysisResult.decisionMaking}
        Social Approach: ${analysisResult.socialApproach}
        Emotional Expression: ${analysisResult.emotionalExpression}
        
        Strengths:
        ${analysisResult.strengths.join('\n')}
        
        Growth Areas:
        ${analysisResult.growthAreas.join('\n')}
        
        Compatibility Insights:
        ${analysisResult.compatibilityInsights}
      `;
      
      await navigator.clipboard.writeText(textResult);
      
      toast({
        title: getTranslation(language, 'analysis.actions.copiedMessage'),
      });
    } catch (error) {
      console.error('Failed to copy results:', error);
      toast({
        title: 'Failed to copy results',
        variant: 'destructive'
      });
    }
  };

  // Download results as image
  const downloadResultsAsImage = async () => {
    if (!analysisResult) return;
    
    try {
      const resultsElement = document.getElementById('results-container');
      if (!resultsElement) return;
      
      const canvas = await html2canvas(resultsElement, {
        backgroundColor: '#1E1E1E', // Match the dark background
        scale: 2, // Higher quality
      });
      
      const dataUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = 'personality-analysis.png';
      link.click();
    } catch (error) {
      console.error('Failed to download results:', error);
      toast({
        title: 'Failed to download results as image',
        variant: 'destructive'
      });
    }
  };

  return {
    analysisResult,
    ocrProgress,
    aiProgress,
    isAnalyzing: analyzeMutation.isPending,
    hasResults: !!analysisResult,
    startAnalysis: (images: string[]) => analyzeMutation.mutate(images),
    copyResultsToClipboard,
    downloadResultsAsImage
  };
}
