import { useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { getTranslation } from '@/i18n';
import type { Language } from '@/i18n';

interface FileWithPreview {
  file: File;
  preview: string;
  id: string;
}

export function useFileUpload(language: Language) {
  const [files, setFiles] = useState<FileWithPreview[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const { toast } = useToast();

  // Convert file to base64 with compression
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      img.onload = () => {
        // تقليل الحجم إذا كانت الصورة كبيرة
        const maxWidth = 1200;
        const maxHeight = 1200;
        let { width, height } = img;
        
        if (width > maxWidth || height > maxHeight) {
          const ratio = Math.min(maxWidth / width, maxHeight / height);
          width *= ratio;
          height *= ratio;
        }
        
        canvas.width = width;
        canvas.height = height;
        
        ctx!.drawImage(img, 0, 0, width, height);
        
        // ضغط الصورة بجودة 80%
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        resolve(dataUrl);
      };
      
      img.onerror = () => {
        // إذا فشل الضغط، استخدم الطريقة الأصلية
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
      };
      
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e) => {
        img.src = e.target!.result as string;
      };
    });
  };

  // Handle file selection
  const handleFiles = useCallback(async (selectedFiles: FileList | null) => {
    if (!selectedFiles || selectedFiles.length === 0) return;

    try {
      // Filter for image files
      const imageFiles = Array.from(selectedFiles).filter(file => 
        file.type === 'image/png' || 
        file.type === 'image/jpeg' || 
        file.type === 'image/jpg'
      );

      if (imageFiles.length === 0) {
        toast({
          title: getTranslation(language, 'errors.fileFormat'),
          variant: 'destructive'
        });
        return;
      }

      // Create file preview objects - one by one to prevent memory issues
      const newFiles: FileWithPreview[] = [];
      for (const file of imageFiles) {
        try {
          const preview = await fileToBase64(file);
          newFiles.push({
            file,
            preview,
            id: Math.random().toString(36).substring(2)
          });
        } catch (err) {
          console.error('Error processing file:', err);
          toast({
            title: 'خطأ في معالجة الملف',
            description: 'حاول مرة أخرى بملف أصغر حجماً',
            variant: 'destructive'
          });
        }
      }

      if (newFiles.length > 0) {
        setFiles(prev => [...prev, ...newFiles]);
      }
    } catch (err) {
      console.error('Error handling files:', err);
      toast({
        title: 'خطأ في تحميل الملفات',
        description: 'حاول مرة أخرى',
        variant: 'destructive'
      });
    }
  }, [language, toast]);

  // Handle file selection from file input
  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    e.stopPropagation();
    handleFiles(e.target.files);
    // Reset the file input value to allow selecting the same file again
    e.target.value = '';
  }, [handleFiles]);

  // Handle file drop
  const handleFileDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  }, [handleFiles]);

  // Handle drag events
  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDragEnter = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  // Remove a file
  const removeFile = useCallback((id: string) => {
    setFiles(prev => prev.filter(file => file.id !== id));
  }, []);

  // Clear all files
  const clearFiles = useCallback(() => {
    setFiles([]);
  }, []);

  // Get base64 strings for all files (for API submission)
  const getBase64Files = useCallback(() => {
    return files.map(file => file.preview);
  }, [files]);

  return {
    files,
    isDragging,
    handleFileSelect,
    handleFileDrop,
    handleDragOver,
    handleDragEnter,
    handleDragLeave,
    removeFile,
    clearFiles,
    getBase64Files,
    hasFiles: files.length > 0
  };
}
