import { Switch, Route } from "wouter";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import { useLanguage } from "@/hooks/useLanguage";
import { getDirection } from "./i18n";
import { useEffect } from "react";
import { ThemeProvider } from "./hooks/ThemeProvider";
import { BackgroundShapes } from "@/components/BackgroundShapes";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const { language } = useLanguage();
  const direction = getDirection(language);

  // Apply RTL direction to HTML element for full site RTL support
  useEffect(() => {
    document.documentElement.dir = direction;
    document.documentElement.lang = language;
  }, [direction, language]);

  return (
    <ThemeProvider>
      <div className={`${direction === 'rtl' ? 'rtl' : ''}`} dir={direction} lang={language}>
        <BackgroundShapes />
        <TooltipProvider>
          <Router />
        </TooltipProvider>
      </div>
    </ThemeProvider>
  );
}

export default App;
