import { Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "../hooks/useTheme";
import { useLanguage } from "@/hooks/useLanguage";
import { getTranslation } from "@/i18n";

export function ThemeSwitcher() {
  const { theme, setTheme } = useTheme();
  const { language } = useLanguage();
  
  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      title={theme === "dark" 
        ? getTranslation(language, 'settings.switchToLight')
        : getTranslation(language, 'settings.switchToDark')
      }
    >
      {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
    </Button>
  );
}