import { useLanguage } from '@/hooks/useLanguage';
import { getTranslation } from '@/i18n';
import { MessageSquare, Shield, Send } from 'lucide-react';

export function Footer() {
  const { language } = useLanguage();
  
  return (
    <footer className="mt-12 border-t border-primary/20 pt-6 bg-gradient-to-b from-transparent to-primary/5 rounded-lg px-4 pb-4">
      <div className="flex items-center justify-center">
        <img 
          src="https://i.ibb.co/5XdHncQ9/file-00000000c67c61f9a15add275c8ea9a8.png" 
          alt="Chataro Logo" 
          className="h-8 w-8 object-contain mr-3"
        />
        <p className="text-muted-foreground text-sm">
          © 2025 Chataro. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
