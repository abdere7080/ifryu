import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { useLanguage } from '@/hooks/useLanguage';
import { getTranslation } from '@/i18n';
import { 
  Share2Icon, 
  FacebookIcon, 
  TwitterIcon, 
  InstagramIcon, 
  LinkedinIcon,
  CheckIcon,
  CopyIcon,
  DownloadIcon
} from 'lucide-react';
import { SiTiktok, SiSnapchat } from 'react-icons/si';
import { PersonalityAnalysis } from '@shared/schema';

interface SocialShareButtonsProps {
  analysisResult: PersonalityAnalysis | null;
  onDownloadImage: () => void;
}

export function SocialShareButtons({ analysisResult, onDownloadImage }: SocialShareButtonsProps) {
  const { language, isRtl } = useLanguage();
  const [copied, setCopied] = useState(false);
  
  if (!analysisResult) return null;
  
  // Generate sharing text based on personality analysis
  const getShareText = () => {
    const baseText = `${getTranslation(language, 'analysis.results.title')}: `;
    const traits = analysisResult.traits.map(t => `${t.name} (${Math.round(t.value * 100)}%)`).join(', ');
    return `${baseText}${traits} #ChataroAI #PersonalityAnalysis`;
  };
  
  const shareText = getShareText();
  
  const handleCopyToClipboard = () => {
    navigator.clipboard.writeText(shareText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const handleShare = (platform: string) => {
    let shareUrl = '';
    const encodedText = encodeURIComponent(shareText);
    const currentUrl = encodeURIComponent(window.location.href);
    
    switch (platform) {
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${currentUrl}&quote=${encodedText}`;
        window.open(shareUrl, '_blank', 'width=600,height=400');
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${encodedText}&url=${currentUrl}`;
        window.open(shareUrl, '_blank', 'width=600,height=400');
        break;
      case 'linkedin':
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${currentUrl}&summary=${encodedText}`;
        window.open(shareUrl, '_blank', 'width=600,height=400');
        break;
      case 'instagram':
      case 'tiktok':
      case 'snapchat':
        // For these platforms, copy text to clipboard as they don't support direct URL sharing
        navigator.clipboard.writeText(`${shareText}\n${window.location.href}`);
        setCopied(true);
        setTimeout(() => setCopied(false), 3000);
        // Show user-friendly message
        const message = isRtl ? 'تم نسخ النص! يمكنك الآن لصقه على المنصة المطلوبة.' : 'Text copied! You can now paste it on the platform.';
        // You can add a toast notification here if needed
        break;
      default:
        return;
    }
  };
  
  return (
    <div className="flex flex-wrap gap-2 mt-4">
      <div className="w-full mb-2">
        <h3 className="text-sm font-medium text-muted-foreground mb-2">
          {isRtl ? 'مشاركة التحليل' : 'Share Analysis'}
        </h3>
      </div>
      
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="outline" 
            size="icon"
            className="h-9 w-9 rounded-full border-primary/20 hover:bg-primary/10 text-primary"
            onClick={() => handleShare('facebook')}
          >
            <FacebookIcon className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Facebook</p>
        </TooltipContent>
      </Tooltip>
      
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="outline" 
            size="icon"
            className="h-9 w-9 rounded-full border-primary/20 hover:bg-primary/10 text-primary"
            onClick={() => handleShare('twitter')}
          >
            <TwitterIcon className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Twitter</p>
        </TooltipContent>
      </Tooltip>
      
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="outline" 
            size="icon"
            className="h-9 w-9 rounded-full border-primary/20 hover:bg-primary/10 text-primary"
            onClick={() => handleShare('linkedin')}
          >
            <LinkedinIcon className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>LinkedIn</p>
        </TooltipContent>
      </Tooltip>
      
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="outline" 
            size="icon"
            className="h-9 w-9 rounded-full border-primary/20 hover:bg-primary/10 text-primary"
            onClick={() => handleShare('instagram')}
          >
            <InstagramIcon className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{isRtl ? 'Instagram - سيتم نسخ النص' : 'Instagram - Copy Text'}</p>
        </TooltipContent>
      </Tooltip>
      
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="outline" 
            size="icon"
            className="h-9 w-9 rounded-full border-primary/20 hover:bg-primary/10 text-primary"
            onClick={() => handleShare('tiktok')}
          >
            <SiTiktok className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{isRtl ? 'TikTok - سيتم نسخ النص' : 'TikTok - Copy Text'}</p>
        </TooltipContent>
      </Tooltip>
      
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="outline" 
            size="icon"
            className="h-9 w-9 rounded-full border-primary/20 hover:bg-primary/10 text-primary"
            onClick={() => handleShare('snapchat')}
          >
            <SiSnapchat className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{isRtl ? 'Snapchat - سيتم نسخ النص' : 'Snapchat - Copy Text'}</p>
        </TooltipContent>
      </Tooltip>
      
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="outline" 
            size="icon"
            className="h-9 w-9 rounded-full border-primary/20 hover:bg-primary/10 text-primary"
            onClick={handleCopyToClipboard}
          >
            {copied ? <CheckIcon className="h-4 w-4 text-green-500" /> : <CopyIcon className="h-4 w-4" />}
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{copied ? getTranslation(language, 'analysis.actions.copiedMessage') : isRtl ? 'نسخ النص' : 'Copy Text'}</p>
        </TooltipContent>
      </Tooltip>
      
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="outline" 
            size="icon"
            className="h-9 w-9 rounded-full border-primary/20 hover:bg-primary/10 text-primary"
            onClick={onDownloadImage}
          >
            <DownloadIcon className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{getTranslation(language, 'analysis.actions.download')}</p>
        </TooltipContent>
      </Tooltip>
    </div>
  );
}