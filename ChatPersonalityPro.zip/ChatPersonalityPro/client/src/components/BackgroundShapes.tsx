import { useTheme } from "@/hooks/useTheme";

export function BackgroundShapes() {
  const { theme } = useTheme();
  
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      {/* Chat Bubbles */}
      <div className="absolute top-10 right-[10%] w-20 h-20 rounded-tl-2xl rounded-tr-2xl rounded-br-2xl bg-primary/5 animate-float-slow transform rotate-12 border border-primary/10" />
      <div className="absolute top-40 left-[15%] w-16 h-16 rounded-tl-2xl rounded-tr-2xl rounded-bl-2xl bg-secondary/5 animate-float-slower transform -rotate-12 border border-secondary/10" />
      <div className="absolute bottom-[30%] right-[5%] w-24 h-20 rounded-tl-2xl rounded-tr-2xl rounded-br-2xl bg-primary/5 animate-float transform rotate-6 border border-primary/10" />
      <div className="absolute top-[20%] right-[20%] w-12 h-12 rounded-full bg-secondary/10 animate-pulse" />

      {/* Social Media Icons */}
      <div className="absolute top-[35%] left-[8%] w-14 h-14 rounded-full bg-gradient-to-r from-primary/5 to-secondary/5 animate-float-slow border border-primary/10 flex items-center justify-center">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-20">
          <path d="M18 2H15C13.6739 2 12.4021 2.52678 11.4645 3.46447C10.5268 4.40215 10 5.67392 10 7V10H7V14H10V22H14V14H17L18 10H14V7C14 6.73478 14.1054 6.48043 14.2929 6.29289C14.4804 6.10536 14.7348 6 15 6H18V2Z" 
            stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      
      <div className="absolute bottom-[15%] left-[12%] w-14 h-14 rounded-full bg-gradient-to-r from-primary/5 to-secondary/5 animate-float-slower border border-primary/10 flex items-center justify-center">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-20">
          <path d="M23 3.00005C22.0424 3.67552 20.9821 4.19216 19.86 4.53005C19.2577 3.83756 18.4573 3.34674 17.567 3.12397C16.6767 2.90121 15.7395 2.95724 14.8821 3.2845C14.0247 3.61176 13.2884 4.19445 12.773 4.95376C12.2575 5.71308 11.9877 6.61238 12 7.53005V8.53005C10.2426 8.57561 8.50127 8.18586 6.93101 7.39549C5.36074 6.60513 4.01032 5.43868 3 4.00005C3 4.00005 -1 13 8 17C5.94053 18.398 3.48716 19.099 1 19C10 24 21 19 21 7.50005C20.9991 7.2215 20.9723 6.94364 20.92 6.67005C21.9406 5.66354 22.6608 4.39276 23 3.00005Z" 
            stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      
      <div className="absolute top-[60%] right-[10%] w-14 h-14 rounded-full bg-gradient-to-r from-primary/5 to-secondary/5 animate-float border border-primary/10 flex items-center justify-center">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-20">
          <rect x="2" y="2" width="20" height="20" rx="5" 
            stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M16 11.37C16.1234 12.2022 15.9813 13.0522 15.5938 13.799C15.2063 14.5458 14.5931 15.1514 13.8416 15.5297C13.0901 15.9079 12.2384 16.0396 11.4078 15.9059C10.5771 15.7723 9.80976 15.3801 9.21484 14.7852C8.61992 14.1902 8.22773 13.4229 8.09407 12.5922C7.9604 11.7615 8.09207 10.9099 8.47033 10.1584C8.84859 9.40685 9.45419 8.79374 10.201 8.40624C10.9478 8.01874 11.7978 7.87659 12.63 8C13.4789 8.12588 14.2649 8.52146 14.8717 9.12831C15.4785 9.73515 15.8741 10.5211 16 11.37Z" 
            stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
          <circle cx="16.5" cy="7.5" r="1.5" 
            stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      
      {/* Image Sharing / Screenshot Concept */}
      <div className="absolute bottom-[30%] left-[25%] w-28 h-20 bg-gradient-to-r from-primary/5 to-secondary/5 rounded-md transform rotate-6 animate-float-slow border border-primary/10">
        <div className="w-full h-3 bg-primary/10 rounded-t-md"></div>
        <div className="flex justify-center items-center h-full">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-20">
            <path d="M19 3H5C3.89543 3 3 3.89543 3 5V19C3 20.1046 3.89543 21 5 21H19C20.1046 21 21 20.1046 21 19V5C21 3.89543 20.1046 3 19 3Z" 
              stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M8.5 10C9.32843 10 10 9.32843 10 8.5C10 7.67157 9.32843 7 8.5 7C7.67157 7 7 7.67157 7 8.5C7 9.32843 7.67157 10 8.5 10Z" 
              stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M21 15L16 10L5 21" 
              stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      </div>
      
      {/* Share Icon */}
      <div className="absolute top-[75%] right-[20%] w-16 h-16 rounded-full bg-gradient-to-r from-primary/10 to-secondary/10 animate-pulse border border-primary/20 flex items-center justify-center">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-30">
          <circle cx="18" cy="5" r="3" 
            stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
          <circle cx="6" cy="12" r="3" 
            stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
          <circle cx="18" cy="19" r="3" 
            stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
          <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" 
            stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
          <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" 
            stroke={theme === 'dark' ? 'white' : 'black'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
    </div>
  );
}