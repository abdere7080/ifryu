import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { getTranslation } from '@/i18n';
import { useLanguage } from '@/hooks/useLanguage';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { SocialShareButtons } from '@/components/SocialShareButtons';
import {
  CopyIcon,
  DownloadIcon,
  CheckCircleIcon,
  LightbulbIcon,
  UserCheckIcon,
  UserXIcon,
  Loader2Icon,
  Sparkles,
  Share2Icon
} from 'lucide-react';
import type { PersonalityAnalysis } from '@shared/schema';

interface ResultsSectionProps {
  isAnalyzing: boolean;
  hasResults: boolean;
  ocrProgress: number;
  aiProgress: number;
  analysisResult: PersonalityAnalysis | null;
  onCopyResults: () => void;
  onDownloadResults: () => void;
}

export function ResultsSection({
  isAnalyzing,
  hasResults,
  ocrProgress,
  aiProgress,
  analysisResult,
  onCopyResults,
  onDownloadResults
}: ResultsSectionProps) {
  const { language, isRtl } = useLanguage();

  // Loading state
  if (isAnalyzing) {
    return (
      <div className="lg:w-1/2">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>{getTranslation(language, 'analysis.loading.title')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex justify-between mb-2">
                <span>{getTranslation(language, 'analysis.loading.ocrStep')}</span>
                <span>{Math.round(ocrProgress)}%</span>
              </div>
              <Progress value={ocrProgress} className="h-2" />
            </div>
            
            <div>
              <div className="flex justify-between mb-2">
                <span>{getTranslation(language, 'analysis.loading.aiStep')}</span>
                <span>{Math.round(aiProgress)}%</span>
              </div>
              <Progress value={aiProgress} className="h-2" />
            </div>
            
            <div className="flex justify-center">
              <div className="inline-flex items-center px-4 py-2 bg-muted rounded-lg">
                <Loader2Icon className={`animate-spin ${isRtl ? 'ml-3' : 'mr-3'} h-5 w-5 text-primary`} />
                <span>{getTranslation(language, 'analysis.loading.waitMessage')}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Results placeholder
  if (!hasResults) {
    return (
      <div className="lg:w-1/2">
        <Card className="shadow-lg h-full flex flex-col items-center justify-center text-center p-6">
          <div className="mb-6 bg-muted rounded-lg w-64 h-48 flex items-center justify-center">
            <Skeleton className="w-full h-full rounded-lg" />
          </div>
          <h2 className="text-xl font-semibold mb-2">
            {getTranslation(language, 'analysis.placeholder.title')}
          </h2>
          <p className="text-muted-foreground mb-6 max-w-md">
            {getTranslation(language, 'analysis.placeholder.description')}
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {(() => {
              const tags = getTranslation(language, 'analysis.placeholder.tags');
              return Array.isArray(tags) ? tags.map((tag: string, index: number) => (
                <span key={index} className="bg-muted px-3 py-1 rounded-full text-sm text-primary">
                  {tag}
                </span>
              )) : null;
            })()}
          </div>
        </Card>
      </div>
    );
  }

  // Results display
  return (
    <div className="lg:w-1/2">
      <div id="results-container">
        <Card className="shadow-lg mb-6 overflow-hidden">
          <div className="bg-gradient-to-r from-primary/20 via-accent/10 to-secondary/20 p-1">
            <CardHeader className="flex flex-row items-start justify-between bg-card rounded-t-md">
              <CardTitle className="flex items-center">
                <Sparkles className="h-5 w-5 text-secondary mr-2" />
                {getTranslation(language, 'analysis.results.title')}
              </CardTitle>
              <div className="flex gap-2">
                <Button variant="outline" size="icon" onClick={onCopyResults} title={getTranslation(language, 'analysis.actions.copy')}>
                  <CopyIcon className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={onDownloadResults} title={getTranslation(language, 'analysis.actions.download')}>
                  <DownloadIcon className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
          </div>
          
          <CardContent className="space-y-6 divide-y divide-border pt-6">
            {/* Relationship Nature Summary */}
            <div className="pb-6">
              <div className="bg-gradient-to-r from-secondary/10 to-primary/10 p-4 rounded-lg mb-4 shadow-inner">
                <h3 className="text-lg font-semibold mb-3 text-primary flex items-center">
                  <Sparkles className="h-4 w-4 text-secondary mr-2" />
                  {getTranslation(language, 'analysis.results.sections.summary')}
                </h3>
                <p className="text-foreground leading-relaxed">
                  {analysisResult?.summary}
                </p>
              </div>
              
              {/* Relationship Nature Categories */}
              <h4 className="text-md font-medium text-accent mb-3">طبيعة العلاقة</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex flex-col bg-gradient-to-br from-primary/5 to-transparent border border-primary/10 rounded-lg p-4 shadow-sm">
                  <span className="text-sm text-primary font-semibold mb-1">
                    {getTranslation(language, 'analysis.results.categories.communicationStyle')}
                  </span>
                  <span className="font-medium text-lg">{analysisResult?.communicationStyle}</span>
                  <div className="h-1 w-1/2 bg-primary/20 rounded-full mt-2"></div>
                </div>
                <div className="flex flex-col bg-gradient-to-br from-secondary/5 to-transparent border border-secondary/10 rounded-lg p-4 shadow-sm">
                  <span className="text-sm text-secondary-foreground font-semibold mb-1">
                    {getTranslation(language, 'analysis.results.categories.decisionMaking')}
                  </span>
                  <span className="font-medium text-lg">{analysisResult?.decisionMaking}</span>
                  <div className="h-1 w-1/2 bg-secondary/20 rounded-full mt-2"></div>
                </div>
                <div className="flex flex-col bg-gradient-to-br from-accent/5 to-transparent border border-accent/10 rounded-lg p-4 shadow-sm">
                  <span className="text-sm text-accent-foreground font-semibold mb-1">
                    {getTranslation(language, 'analysis.results.categories.socialApproach')}
                  </span>
                  <span className="font-medium text-lg">{analysisResult?.socialApproach}</span>
                  <div className="h-1 w-1/2 bg-accent/20 rounded-full mt-2"></div>
                </div>
                <div className="flex flex-col bg-gradient-to-br from-primary/5 to-transparent border border-primary/10 rounded-lg p-4 shadow-sm">
                  <span className="text-sm text-primary font-semibold mb-1">
                    {getTranslation(language, 'analysis.results.categories.emotionalExpression')}
                  </span>
                  <span className="font-medium text-lg">{analysisResult?.emotionalExpression}</span>
                  <div className="h-1 w-1/2 bg-primary/20 rounded-full mt-2"></div>
                </div>
              </div>
            </div>
            
            {/* Relationship Traits Section */}
            <div className="py-6">
              <div className="flex items-center mb-4">
                <div className="bg-primary/20 rounded-full p-2 mr-3">
                  <Sparkles className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-lg font-medium text-primary">
                  مؤشرات العلاقة
                </h3>
              </div>
              <div className="bg-muted/50 rounded-lg p-6 shadow-inner">
                <div className="space-y-4">
                  {analysisResult?.traits.map((trait, index) => (
                    <div key={index} className="flex flex-col">
                      <div className="flex justify-between mb-2 items-center">
                        <span className="font-semibold text-foreground">{trait.name}</span>
                        <span className="text-sm px-3 py-1 bg-primary/10 rounded-full text-primary font-medium">{trait.value}%</span>
                      </div>
                      <Progress 
                        value={trait.value}
                        className="h-3 rounded-full"
                        style={{ 
                          '--progress-background': trait.color 
                        } as React.CSSProperties}
                      />
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>منخفض</span>
                        <span>متوسط</span>
                        <span>مرتفع</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Communication Patterns - Relationship Dynamics */}
            <div className="py-6">
              <div className="flex items-center mb-4">
                <div className="bg-accent/20 rounded-full p-2 mr-3">
                  <LightbulbIcon className="h-5 w-5 text-accent" />
                </div>
                <h3 className="text-lg font-medium text-accent">
                  ديناميكيات التواصل في العلاقة
                </h3>
              </div>
              <div className="space-y-4 mt-2">
                {analysisResult?.communicationPatterns.map((pattern, index) => (
                  <div key={index} className="bg-gradient-to-r from-accent/5 to-transparent border border-accent/10 rounded-lg p-5 shadow-sm">
                    <h4 className="font-semibold mb-2 text-accent-foreground">{pattern.title}</h4>
                    <p className="text-foreground">{pattern.description}</p>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Strengths & Growth Areas */}
            <div className="py-6">
              <div className="flex items-center mb-4">
                <div className="bg-primary/20 rounded-full p-2 mr-3">
                  <CheckCircleIcon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-lg font-medium text-primary">
                  نقاط القوة والتطوير في العلاقة
                </h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gradient-to-r from-green-50 to-transparent border border-green-100 rounded-lg p-5 shadow-sm">
                  <h4 className="font-semibold text-green-600 mb-3 flex items-center">
                    <CheckCircleIcon className={`${isRtl ? 'ml-2' : 'mr-2'} h-5 w-5`} />
                    نقاط القوة
                  </h4>
                  <ul className={`space-y-2 text-foreground`}>
                    {analysisResult?.strengths.map((strength, index) => (
                      <li key={index} className="flex items-start">
                        <span className="inline-block bg-green-100 text-green-600 rounded-full p-1 mr-2 mt-0.5">
                          <CheckCircleIcon className="h-3 w-3" />
                        </span>
                        <span>{strength}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-gradient-to-r from-amber-50 to-transparent border border-amber-100 rounded-lg p-5 shadow-sm">
                  <h4 className="font-semibold text-amber-600 mb-3 flex items-center">
                    <LightbulbIcon className={`${isRtl ? 'ml-2' : 'mr-2'} h-5 w-5`} />
                    مجالات التطوير
                  </h4>
                  <ul className={`space-y-2 text-foreground`}>
                    {analysisResult?.growthAreas.map((area, index) => (
                      <li key={index} className="flex items-start">
                        <span className="inline-block bg-amber-100 text-amber-600 rounded-full p-1 mr-2 mt-0.5">
                          <LightbulbIcon className="h-3 w-3" />
                        </span>
                        <span>{area}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Compatibility Insights */}
        <Card className="shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-secondary/20 via-accent/10 to-primary/20 p-1">
            <CardHeader className="bg-card rounded-t-md">
              <CardTitle className="flex items-center">
                <Sparkles className="h-5 w-5 text-secondary mr-2" />
                توافق العلاقة
              </CardTitle>
            </CardHeader>
          </div>
          <CardContent className="pt-6 pb-8">
            <div className="bg-gradient-to-r from-primary/5 to-transparent border border-primary/10 rounded-lg p-6 mb-6 shadow-sm">
              <p className="text-foreground leading-relaxed">
                {analysisResult?.compatibilityInsights}
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="bg-gradient-to-br from-green-50 to-transparent border border-green-100 rounded-lg p-5 shadow-sm">
                <h4 className="font-semibold text-green-600 mb-4 flex items-center">
                  <div className="bg-green-100 rounded-full p-1.5 mr-2">
                    <UserCheckIcon className="h-5 w-5" />
                  </div>
                  <span>تتوافق بشكل جيد مع</span>
                </h4>
                <ul className="space-y-3">
                  {analysisResult?.worksWellWith.map((trait, index) => (
                    <li key={index} className="flex items-start bg-white/50 p-3 rounded-md shadow-sm">
                      <span className="inline-block bg-green-100 text-green-600 rounded-full p-1 mr-2 mt-0.5">
                        <CheckCircleIcon className="h-3 w-3" />
                      </span>
                      <span className="font-medium text-foreground">{trait}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-gradient-to-br from-red-50 to-transparent border border-red-100 rounded-lg p-5 shadow-sm">
                <h4 className="font-semibold text-red-600 mb-4 flex items-center">
                  <div className="bg-red-100 rounded-full p-1.5 mr-2">
                    <UserXIcon className="h-5 w-5" />
                  </div>
                  <span>تحديات محتملة مع</span>
                </h4>
                <ul className="space-y-3">
                  {analysisResult?.challengesWith.map((trait, index) => (
                    <li key={index} className="flex items-start bg-white/50 p-3 rounded-md shadow-sm">
                      <span className="inline-block bg-red-100 text-red-600 rounded-full p-1 mr-2 mt-0.5">
                        <LightbulbIcon className="h-3 w-3" />
                      </span>
                      <span className="font-medium text-foreground">{trait}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Social Sharing Section */}
        <div className="mt-6 bg-gradient-to-r from-primary/5 to-secondary/5 rounded-lg p-5 shadow-sm border border-primary/10">
          <div className="flex items-center mb-4">
            <div className="bg-primary/20 rounded-full p-2 mr-3">
              <Share2Icon className="h-5 w-5 text-primary" />
            </div>
            <h3 className="text-lg font-medium text-primary">
              {isRtl ? 'مشاركة النتائج' : 'Share Results'}
            </h3>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            {isRtl 
              ? 'يمكنك مشاركة نتائج التحليل على وسائل التواصل الاجتماعي أو تحميلها كصورة للمشاركة مع الآخرين.' 
              : 'Share your personality analysis results on social media or download as image to share with others.'}
          </p>
          <SocialShareButtons analysisResult={analysisResult} onDownloadImage={onDownloadResults} />
        </div>
      </div>
    </div>
  );
}
