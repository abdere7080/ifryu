import { useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { getTranslation } from '@/i18n';
import { useLanguage } from '@/hooks/useLanguage';
import { useFileUpload } from '@/hooks/useFileUpload';
import { cn } from '@/lib/utils';
import { 
  BrainIcon, 
  CloudIcon, 
  TrashIcon, 
  XIcon, 
  Loader2Icon,
  ImagePlusIcon,
  ImageIcon,
  CheckCircleIcon,
  AlertCircleIcon,
  UploadCloudIcon
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

interface UploadSectionProps {
  onStartAnalysis: () => void;
  isAnalyzing: boolean;
  fileUpload: any;
}

export function UploadSection({ onStartAnalysis, isAnalyzing, fileUpload }: UploadSectionProps) {
  const { language, isRtl } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadView, setUploadView] = useState<'grid' | 'list'>('grid');
  const [hoveringImage, setHoveringImage] = useState<string | null>(null);
  const {
    files,
    isDragging,
    handleFileSelect,
    handleFileDrop,
    handleDragOver,
    handleDragEnter,
    handleDragLeave,
    removeFile,
    clearFiles,
    getBase64Files,
    hasFiles
  } = fileUpload;

  const handleStartAnalysis = () => {
    if (hasFiles && !isAnalyzing) {
      onStartAnalysis();
    }
  };

  return (
    <div className="lg:w-1/2 flex flex-col gap-6">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>{getTranslation(language, 'upload.title')}</CardTitle>
          <p className="text-muted-foreground">
            {getTranslation(language, 'upload.description')}
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* File Upload Area */}
          <div 
            className={cn(
              "border-2 border-dashed border-secondary rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer transition-colors",
              isDragging ? "border-primary bg-secondary/10" : "hover:border-primary/70 bg-gradient-to-b from-primary/5 to-secondary/5"
            )}
            onClick={() => fileInputRef.current?.click()}
            onDragOver={handleDragOver}
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDrop={handleFileDrop}
          >
            <CloudIcon className="h-12 w-12 text-primary mb-4" />
            <p className="text-center mb-2 font-semibold text-primary">
              {getTranslation(language, 'upload.dropzone.title')}
            </p>
            <p className="text-muted-foreground text-sm text-center mb-4">
              {getTranslation(language, 'upload.dropzone.supportedFormats')}
            </p>
            <div className="flex flex-col items-center gap-2">
              <Button variant="outline" className="border-secondary hover:bg-secondary/10 hover:text-primary">
                {getTranslation(language, 'upload.dropzone.browseButton')}
              </Button>
              <p className="text-xs text-accent font-medium">{isRtl ? 'يمكنك تحميل صورة واحدة أو عدة صور معاً' : 'You can upload one or multiple images'}</p>
            </div>
            <input 
              type="file" 
              className="hidden" 
              ref={fileInputRef}
              accept=".png,.jpg,.jpeg" 
              multiple 
              onChange={handleFileSelect}
            />
          </div>
          
          {/* Selected Files Preview */}
          {hasFiles && (
            <div>
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center">
                  <h3 className="text-lg font-medium">
                    {getTranslation(language, 'upload.selectedFiles')}
                  </h3>
                  <Badge variant="outline" className="ml-2 bg-primary/10 text-primary">
                    {files.length}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex border rounded-md overflow-hidden">
                    <Button 
                      variant={uploadView === 'grid' ? 'default' : 'ghost'} 
                      size="sm" 
                      className="rounded-none h-8 px-2"
                      onClick={() => setUploadView('grid')}
                    >
                      <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-4 w-4">
                        <path d="M1.5 1H6.5V6H1.5V1ZM8.5 1H13.5V6H8.5V1ZM1.5 8H6.5V13H1.5V8ZM8.5 8H13.5V13H8.5V8Z" stroke="currentColor" strokeWidth="1.2" />
                      </svg>
                    </Button>
                    <Button 
                      variant={uploadView === 'list' ? 'default' : 'ghost'} 
                      size="sm" 
                      className="rounded-none h-8 px-2"
                      onClick={() => setUploadView('list')}
                    >
                      <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-4 w-4">
                        <path d="M1.5 2H13.5M1.5 7.5H13.5M1.5 13H13.5" stroke="currentColor" strokeWidth="1.2" />
                      </svg>
                    </Button>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex items-center gap-1"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isAnalyzing}
                  >
                    <ImagePlusIcon className="h-4 w-4" />
                    <span>{isRtl ? "إضافة المزيد" : "Add More"}</span>
                  </Button>
                </div>
              </div>
              
              {uploadView === 'grid' ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 bg-muted/50 p-3 rounded-lg">
                  {files.map((file) => (
                    <div 
                      key={file.id} 
                      className="group relative bg-muted border rounded-lg overflow-hidden h-[140px] transition-all hover:scale-[1.02] hover:shadow-md" 
                      onMouseEnter={() => setHoveringImage(file.id)}
                      onMouseLeave={() => setHoveringImage(null)}
                    >
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="absolute inset-x-0 bottom-0 p-2">
                          <p className="text-xs text-white truncate font-medium">{file.file.name}</p>
                          <p className="text-xs text-white/70">{(file.file.size / 1024).toFixed(0)} KB</p>
                        </div>
                      </div>
                      <Button 
                        variant="destructive" 
                        size="icon" 
                        className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={(e) => {
                          e.stopPropagation();
                          removeFile(file.id);
                        }}
                      >
                        <XIcon className="h-3 w-3" />
                      </Button>
                      
                      <div className="w-full h-full">
                        <img 
                          src={file.preview} 
                          alt={file.file.name} 
                          className="w-full h-full object-cover" 
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <ScrollArea className="h-[300px] bg-muted/50 p-2 rounded-lg">
                  <div className="space-y-2">
                    {files.map((file) => (
                      <div key={file.id} className="flex items-center bg-background p-3 rounded-lg border transition-colors hover:bg-muted/30">
                        <div className="w-16 h-16 bg-background rounded overflow-hidden mr-3">
                          <img 
                            src={file.preview} 
                            alt={file.file.name} 
                            className="w-full h-full object-cover" 
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{file.file.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {(file.file.size / 1024).toFixed(0)} KB
                          </p>
                          <Progress 
                            value={100} 
                            className="h-1 mt-1" 
                          />
                        </div>
                        <div className="flex items-center gap-1 ml-2">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-emerald-500 rounded-full h-8 w-8"
                          >
                            <CheckCircleIcon className="h-5 w-5" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-muted-foreground hover:text-destructive rounded-full h-8 w-8"
                            onClick={(e) => {
                              e.stopPropagation();
                              removeFile(file.id);
                            }}
                          >
                            <XIcon className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>
          )}
          
          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              className="flex-1"
              disabled={!hasFiles || isAnalyzing}
              onClick={handleStartAnalysis}
            >
              {isAnalyzing ? (
                <>
                  <Loader2Icon className={`${isRtl ? 'ml-2' : 'mr-2'} h-4 w-4 animate-spin`} />
                  {getTranslation(language, 'upload.buttons.analyzing')}
                </>
              ) : (
                <>
                  <BrainIcon className={`${isRtl ? 'ml-2' : 'mr-2'} h-4 w-4`} />
                  {getTranslation(language, 'upload.buttons.startAnalysis')}
                </>
              )}
            </Button>
            
            {hasFiles && (
              <Button 
                variant="outline" 
                className="flex-1 border-secondary text-secondary hover:text-secondary/80 hover:bg-secondary/10"
                onClick={clearFiles}
                disabled={isAnalyzing}
              >
                <TrashIcon className={`${isRtl ? 'ml-2' : 'mr-2'} h-4 w-4`} />
                {getTranslation(language, 'upload.buttons.clearAll')}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

    </div>
  );
}