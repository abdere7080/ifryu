import React from 'react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useLanguage } from '@/hooks/useLanguage';
import { getTranslation } from '@/i18n';

export function AuthButton() {
  const { user, isAuthenticated } = useAuth();
  const { language } = useLanguage();

  if (isAuthenticated && user) {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-10 w-10 rounded-full">
            <Avatar className="h-9 w-9">
              <AvatarImage src={user.profileImageUrl || undefined} alt={user.name || 'مستخدم'} />
              <AvatarFallback>{getUserInitials(user)}</AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56" align="end" forceMount>
          <DropdownMenuLabel>
            <div className="flex flex-col space-y-1">
              <p className="text-sm font-medium leading-none">{user.name || 'مستخدم'}</p>
              <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild>
            <a href="/api/analyses">
              سجل التحليلات
            </a>
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild>
            <a href="/auth/logout" className="text-red-600 cursor-pointer">
              تسجيل الخروج
            </a>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  return (
    <Button
      variant="outline"
      className="gap-2 border-primary/30 text-primary hover:bg-primary/10 hover:text-primary"
      onClick={() => window.location.href = '/auth/google'}
    >
      <GoogleIcon className="h-4 w-4" />
      <span>{getTranslation(language, 'auth.loginWithGoogle')}</span>
    </Button>
  );
}

function getUserInitials(user: { name: string | null }): string {
  if (!user.name) return 'U';
  const nameParts = user.name.split(' ');
  if (nameParts.length === 1) return nameParts[0].charAt(0).toUpperCase();
  return (nameParts[0].charAt(0) + nameParts[nameParts.length - 1].charAt(0)).toUpperCase();
}

function GoogleIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
    >
      <path
        fill="currentColor"
        d="M12.545 12.151c0 .269-.025.533-.074.788h-5.35v-1.669h3.046c-.066-.435-.288-.81-.62-1.092v-.908h1.512c.444.435.686 1.035.686 1.881zm-5.424 3.152c-.418-.123-.771-.312-1.05-.538l1.005-.809c.275.197.595.348.964.418.369.073.739.04 1.089-.097.35-.137.629-.349.84-.645l1.005.809c-.319.418-.738.756-1.274.993-.536.238-1.099.316-1.685.237-.587-.078-1.113-.271-1.578-.578-.465-.307-.799-.7-1.001-1.181-.202-.481-.29-.99-.264-1.529.025-.539.146-1.037.361-1.494.215-.458.522-.837.919-1.137.397-.3.854-.5 1.371-.6l.9 1.14c-.369.123-.683.305-.944.546-.26.238-.44.515-.541.828-.101.314-.122.635-.061.962.061.328.187.608.38.842.193.233.447.4.76.5.314.099.638.108.973.027zm10.254-4.764c.202.513.303 1.059.303 1.636 0 .577-.101 1.123-.303 1.636-.202.512-.474.954-.818 1.326-.344.371-.747.662-1.208.87-.461.21-.952.314-1.474.314-.522 0-1.013-.105-1.474-.314-.461-.208-.864-.499-1.208-.87-.344-.372-.616-.814-.818-1.326-.202-.513-.303-1.059-.303-1.636 0-.577.101-1.123.303-1.636.202-.512.474-.954.818-1.326.344-.371.747-.662 1.208-.871.461-.208.952-.314 1.474-.313.522 0 1.013.105 1.474.313.461.21.864.5 1.208.871.344.372.616.814.818 1.326zm-1.121 2
.753c.132-.332.197-.702.197-1.117 0-.415-.065-.785-.197-1.117s-.308-.603-.542-.807c-.234-.204-.51-.306-.83-.306-.319 0-.596.102-.83.306-.234.204-.41.475-.542.807-.132.332-.197.702-.197 1.117 0 .415.065.785.197 1.117s.308.603.542.807c.234.204.511.306.83.306.319 0 .596-.102.83-.306.234-.204.41-.475.542-.807z"
      />
    </svg>
  );
}