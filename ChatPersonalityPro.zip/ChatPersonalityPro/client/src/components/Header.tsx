import { useLanguage } from '@/hooks/useLanguage';
import { getTranslation } from '@/i18n';
import { Button } from '@/components/ui/button';
import { Bot, MessageSquare, Sparkles, Moon, Sun } from 'lucide-react';
import { useTheme } from '@/hooks/useTheme';

export function Header() {
  const { language, changeLanguage } = useLanguage();
  const { theme, setTheme } = useTheme();
  
  return (
    <header className="flex flex-col md:flex-row justify-between items-center gap-4 mb-8 bg-gradient-to-r from-primary/20 to-secondary/20 p-4 rounded-lg backdrop-blur-sm shadow-sm">
      <div className="flex items-center group">
        <div className="mr-3">
          <img 
            src="https://i.ibb.co/5XdHncQ9/file-00000000c67c61f9a15add275c8ea9a8.png" 
            alt="Chataro Logo" 
            className="h-12 w-12 object-contain"
          />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-primary group-hover:text-accent transition-colors duration-300">
            {getTranslation(language, 'appName')}
            <Sparkles className="inline-block h-5 w-5 ml-1 text-secondary animate-pulse" />
          </h1>
          <p className="text-xs text-secondary-foreground font-medium">
            {getTranslation(language, 'header.tagline')}
          </p>
        </div>
      </div>
      
      <div className="flex items-center gap-3">
        {/* Theme Switcher */}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          title={theme === "dark" 
            ? getTranslation(language, 'settings.switchToLight')
            : getTranslation(language, 'settings.switchToDark')
          }
          className="rounded-full bg-muted/70 hover:bg-secondary/20"
        >
          {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
        
        {/* Language Switcher */}
        <div className="flex items-center flex-wrap gap-1 bg-muted/70 backdrop-blur-sm rounded-full p-1 border border-secondary/30 shadow-inner">
          <Button
            onClick={() => changeLanguage('en')}
            variant={language === 'en' ? 'default' : 'ghost'}
            size="sm"
            className={`rounded-full px-2 py-1 text-xs transition-all duration-300 ${language === 'en' ? 'bg-primary hover:bg-primary/90 shadow-md' : 'text-muted-foreground hover:text-foreground hover:bg-secondary/10'}`}
          >
            {getTranslation(language, 'header.languages.en')}
          </Button>
          <Button
            onClick={() => changeLanguage('ar')}
            variant={language === 'ar' ? 'default' : 'ghost'}
            size="sm"
            className={`rounded-full px-2 py-1 text-xs transition-all duration-300 ${language === 'ar' ? 'bg-primary hover:bg-primary/90 shadow-md' : 'text-muted-foreground hover:text-foreground hover:bg-secondary/10'}`}
          >
            {getTranslation(language, 'header.languages.ar')}
          </Button>
          <Button
            onClick={() => changeLanguage('fr')}
            variant={language === 'fr' ? 'default' : 'ghost'}
            size="sm"
            className={`rounded-full px-2 py-1 text-xs transition-all duration-300 ${language === 'fr' ? 'bg-primary hover:bg-primary/90 shadow-md' : 'text-muted-foreground hover:text-foreground hover:bg-secondary/10'}`}
          >
            {getTranslation(language, 'header.languages.fr')}
          </Button>
          <Button
            onClick={() => changeLanguage('es')}
            variant={language === 'es' ? 'default' : 'ghost'}
            size="sm"
            className={`rounded-full px-2 py-1 text-xs transition-all duration-300 ${language === 'es' ? 'bg-primary hover:bg-primary/90 shadow-md' : 'text-muted-foreground hover:text-foreground hover:bg-secondary/10'}`}
          >
            {getTranslation(language, 'header.languages.es')}
          </Button>

          <Button
            onClick={() => changeLanguage('ja')}
            variant={language === 'ja' ? 'default' : 'ghost'}
            size="sm"
            className={`rounded-full px-2 py-1 text-xs transition-all duration-300 ${language === 'ja' ? 'bg-primary hover:bg-primary/90 shadow-md' : 'text-muted-foreground hover:text-foreground hover:bg-secondary/10'}`}
          >
            {getTranslation(language, 'header.languages.ja')}
          </Button>
        </div>
      </div>
    </header>
  );
}
