import { useEffect } from 'react';
import { Header } from '@/components/Header';
import { UploadSection } from '@/components/UploadSection';
import { ResultsSection } from '@/components/ResultsSection';
import { Footer } from '@/components/Footer';
import { useLanguage } from '@/hooks/useLanguage';
import { useFileUpload } from '@/hooks/useFileUpload';
import { useAnalysis } from '@/hooks/useAnalysis';

export default function Home() {
  const { language } = useLanguage();
  const fileUpload = useFileUpload(language);
  const { 
    files, 
    hasFiles, 
    getBase64Files,
    clearFiles 
  } = fileUpload;
  
  const {
    analysisResult,
    ocrProgress,
    aiProgress,
    isAnalyzing,
    hasResults,
    startAnalysis,
    copyResultsToClipboard,
    downloadResultsAsImage
  } = useAnalysis(language);

  const handleStartAnalysis = () => {
    if (hasFiles && !isAnalyzing) {
      const base64Files = getBase64Files();
      startAnalysis(base64Files);
    }
  };



  return (
    <div className="bg-background text-foreground min-h-screen">
      {/* خلفية زخرفية - تصميم نمط محادثات */}
      <div className="chat-pattern"></div>
      
      <div className="max-w-7xl mx-auto px-4 py-8 md:px-8 relative">
        <Header />
        
        {/* زخرفة إضافية - العناصر المتحركة */}
        <div className="absolute top-24 right-4 w-16 h-16 rounded-full bg-primary/5 blur-xl animate-pulse"></div>
        <div className="absolute bottom-24 left-4 w-12 h-12 rounded-full bg-secondary/5 blur-xl animate-pulse" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-60 h-60 rounded-full bg-accent/3 blur-3xl animate-pulse opacity-30" style={{animationDelay: '2s'}}></div>
        
        {/* بطاقة عرض الصورة */}
        <div className="mb-8 bg-gradient-to-r from-primary/10 via-secondary/5 to-accent/10 p-1 rounded-xl shadow-lg">
          <div className="bg-card rounded-lg p-6 overflow-hidden">
            <div className="flex flex-col items-center space-y-4">
              <div className="w-full max-w-2xl rounded-lg overflow-hidden shadow-lg">
                <img 
                  src="https://i.ibb.co/xtzhF20t/file-00000000525861f88543097ff57de051.png" 
                  alt="Future Project Example" 
                  className="w-full h-auto object-cover"
                />
              </div>
              <div className="text-center space-y-2">
                <h3 className="text-xl font-bold text-primary">Future Project</h3>
                <p className="text-muted-foreground">
                  This represents our upcoming personality analysis features and capabilities
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* بطاقة شرح استعمال الموقع */}
        <div className="mb-8 bg-gradient-to-r from-secondary/10 via-primary/5 to-accent/10 p-1 rounded-xl shadow-lg">
          <div className="bg-card rounded-lg p-6">
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-bold text-secondary">How to Use This Website</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="bg-primary/20 rounded-full w-8 h-8 flex items-center justify-center">
                      <span className="text-primary font-bold">1</span>
                    </div>
                    <h4 className="font-semibold text-lg">Upload Screenshots</h4>
                  </div>
                  <p className="text-muted-foreground">
                    Upload screenshots of your chat conversations. The system supports PNG, JPG, and JPEG formats.
                  </p>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="bg-secondary/20 rounded-full w-8 h-8 flex items-center justify-center">
                      <span className="text-secondary font-bold">2</span>
                    </div>
                    <h4 className="font-semibold text-lg">AI Analysis</h4>
                  </div>
                  <p className="text-muted-foreground">
                    Our advanced OCR technology extracts text from your images, then AI analyzes communication patterns and personality traits.
                  </p>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="bg-accent/20 rounded-full w-8 h-8 flex items-center justify-center">
                      <span className="text-accent font-bold">3</span>
                    </div>
                    <h4 className="font-semibold text-lg">Get Results</h4>
                  </div>
                  <p className="text-muted-foreground">
                    Receive detailed personality insights including traits, communication styles, strengths, and compatibility analysis.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        
        <main className="flex flex-col lg:flex-row gap-8 relative z-10">
          <UploadSection 
            onStartAnalysis={handleStartAnalysis} 
            isAnalyzing={isAnalyzing}
            fileUpload={fileUpload}
          />
          
          <ResultsSection 
            isAnalyzing={isAnalyzing}
            hasResults={hasResults}
            ocrProgress={ocrProgress}
            aiProgress={aiProgress}
            analysisResult={analysisResult}
            onCopyResults={copyResultsToClipboard}
            onDownloadResults={downloadResultsAsImage}
          />
        </main>
        
        <Footer />
      </div>
    </div>
  );
}
