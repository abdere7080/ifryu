const translations: Record<string, any> = {
  en: {
    appName: "Chataro",
    header: {
      tagline: "AI Personality Analyzer",
      languages: {
        en: "English",
        ar: "العربية",
        fr: "Français",
        es: "Español",
        zh: "中文",
        ja: "日本語"
      },
    },
    settings: {
      switchToDark: "Switch to dark mode",
      switchToLight: "Switch to light mode",
      theme: "Theme",
      language: "Language",
    },
    upload: {
      title: "Upload Chat Screenshot",
      description: "Upload your chat conversation screenshots and our AI will analyze the personality traits.",
      dropzone: {
        title: "Drag & drop your chat screenshots here",
        supportedFormats: "Supports PNG, JPG, JPEG",
        browseButton: "Browse Files",
      },
      selectedFiles: "Selected Files",
      buttons: {
        startAnalysis: "Start Analysis",
        clearAll: "Clear All",
        analyzing: "Analyzing...",
      },
    },
    howItWorks: {
      title: "How It Works",
      steps: [
        {
          number: "1",
          title: "Upload",
          description: "Upload screenshots of chat conversations.",
        },
        {
          number: "2",
          title: "Extract",
          description: "Our OCR technology extracts text from your images.",
        },
        {
          number: "3",
          title: "Analyze",
          description: "Advanced AI analyzes communication patterns.",
        },
        {
          number: "4",
          title: "Results",
          description: "Get detailed personality insights you can share.",
        },
      ],
    },
    analysis: {
      loading: {
        title: "Analyzing Chat...",
        ocrStep: "Extracting text from images",
        aiStep: "Analyzing personality traits",
        waitMessage: "This may take a few moments",
      },
      placeholder: {
        title: "Your Personality Analysis Will Appear Here",
        description: "Upload chat conversation screenshots and let our AI analyze the personality traits within the messages.",
        tags: [
          "Communication Style",
          "Emotional Patterns",
          "Social Dynamics",
          "Personality Traits",
        ],
      },
      results: {
        title: "Personality Analysis Results",
        sections: {
          summary: "Personality Summary",
          traits: "Personality Traits",
          communicationPatterns: "Communication Patterns",
          strengthsAreas: "Strengths & Growth Areas",
          compatibilityInsights: "Compatibility Insights",
        },
        categories: {
          communicationStyle: "Communication Style",
          decisionMaking: "Decision Making",
          socialApproach: "Social Approach",
          emotionalExpression: "Emotional Expression",
        },
        strengthsTitle: "Strengths",
        growthAreasTitle: "Growth Areas",
        worksWellWith: "Works Well With",
        challengesWith: "May Have Challenges With",
      },
      actions: {
        copy: "Copy Results",
        download: "Download as Image",
        copiedMessage: "Results copied to clipboard!",
      },
      social: {
        shareTitle: "Share Your Analysis",
        copyText: "Copy Text",
        copiedForSocial: "Text copied! You can now paste it on Instagram, TikTok or Snapchat.",
      },
    },
    footer: {
      copyright: "© 2023 Chataro - AI Personality Analyzer",
      poweredBy: "Powered by OCR.Space and OpenAI GPT-4",
      links: {
        privacy: "Privacy Policy",
        terms: "Terms of Service",
        contact: "Contact",
      },
    },
    errors: {
      fileFormat: "Please select valid image files (PNG, JPG, JPEG).",
      ocrFailed: "Failed to extract text from images. Please try again.",
      analysisFailed: "Failed to analyze personality. Please try again.",
      generic: "Something went wrong. Please try again.",
    },
  },
  ar: {
    appName: "شاتارو",
    header: {
      tagline: "محلل الشخصية بالذكاء الاصطناعي",
      languages: {
        en: "English",
        ar: "العربية",
        fr: "Français",
        es: "Español",
        zh: "中文",
        ja: "日本語"
      },
    },
    settings: {
      switchToDark: "التبديل إلى الوضع الداكن",
      switchToLight: "التبديل إلى الوضع الفاتح",
      theme: "المظهر",
      language: "اللغة",
    },
    upload: {
      title: "تحميل لقطة شاشة للدردشة",
      description: "قم بتحميل لقطات شاشة محادثاتك وسيقوم الذكاء الاصطناعي بتحليل سمات الشخصية.",
      dropzone: {
        title: "اسحب وأفلت لقطات شاشة الدردشة هنا",
        supportedFormats: "يدعم PNG، JPG، JPEG",
        browseButton: "تصفح الملفات",
      },
      selectedFiles: "الملفات المحددة",
      buttons: {
        startAnalysis: "بدء التحليل",
        clearAll: "مسح الكل",
        analyzing: "جاري التحليل...",
      },
    },
    howItWorks: {
      title: "كيف يعمل",
      steps: [
        {
          number: "١",
          title: "تحميل",
          description: "قم بتحميل لقطات شاشة محادثات الدردشة.",
        },
        {
          number: "٢",
          title: "استخراج",
          description: "تقنية التعرف الضوئي على النصوص تستخرج النص من صورك.",
        },
        {
          number: "٣",
          title: "تحليل",
          description: "يحلل الذكاء الاصطناعي المتقدم أنماط التواصل.",
        },
        {
          number: "٤",
          title: "النتائج",
          description: "احصل على رؤى مفصلة عن الشخصية يمكنك مشاركتها.",
        },
      ],
    },
    analysis: {
      loading: {
        title: "تحليل الدردشة...",
        ocrStep: "استخراج النص من الصور",
        aiStep: "تحليل سمات الشخصية",
        waitMessage: "قد يستغرق هذا بضع لحظات",
      },
      placeholder: {
        title: "سيظهر تحليل شخصيتك هنا",
        description: "قم بتحميل لقطات شاشة محادثات الدردشة ودع الذكاء الاصطناعي يحلل سمات الشخصية في الرسائل.",
        tags: [
          "أسلوب التواصل",
          "الأنماط العاطفية",
          "الديناميكيات الاجتماعية",
          "سمات الشخصية",
        ],
      },
      results: {
        title: "نتائج تحليل الشخصية",
        sections: {
          summary: "ملخص الشخصية",
          traits: "سمات الشخصية",
          communicationPatterns: "أنماط الاتصال",
          strengthsAreas: "نقاط القوة ومجالات النمو",
          compatibilityInsights: "رؤى التوافق",
        },
        categories: {
          communicationStyle: "أسلوب التواصل",
          decisionMaking: "صنع القرار",
          socialApproach: "النهج الاجتماعي",
          emotionalExpression: "التعبير العاطفي",
        },
        strengthsTitle: "نقاط القوة",
        growthAreasTitle: "مجالات النمو",
        worksWellWith: "يعمل بشكل جيد مع",
        challengesWith: "قد يواجه تحديات مع",
      },
      actions: {
        copy: "نسخ النتائج",
        download: "تنزيل كصورة",
        copiedMessage: "تم نسخ النتائج إلى الحافظة!",
      },
      social: {
        shareTitle: "شارك تحليلك",
        copyText: "نسخ النص",
        copiedForSocial: "تم نسخ النص! يمكنك الآن لصقه على Instagram أو TikTok أو Snapchat.",
      },
    },
    footer: {
      copyright: "© 2023 شاتارو - محلل الشخصية بالذكاء الاصطناعي",
      poweredBy: "مدعوم بواسطة OCR.Space و OpenAI GPT-4",
      links: {
        privacy: "سياسة الخصوصية",
        terms: "شروط الخدمة",
        contact: "اتصل بنا",
      },
    },
    errors: {
      fileFormat: "الرجاء تحديد ملفات صور صالحة (PNG، JPG، JPEG).",
      ocrFailed: "فشل استخراج النص من الصور. الرجاء المحاولة مرة أخرى.",
      analysisFailed: "فشل تحليل الشخصية. الرجاء المحاولة مرة أخرى.",
      generic: "حدث خطأ ما. الرجاء المحاولة مرة أخرى.",
    },
  },
};

export type Language = 'en' | 'ar' | 'fr' | 'es' | 'ja';
export type TranslationKey = keyof typeof translations.en;

// إضافة اللغة الفرنسية
translations.fr = {
  appName: "Chataro",
  header: {
    tagline: "Analyseur de Personnalité IA",
    languages: {
      en: "English",
      ar: "العربية",
      fr: "Français"
    },
  },
  settings: {
    switchToDark: "Passer au mode sombre",
    switchToLight: "Passer au mode clair",
    theme: "Thème",
    language: "Langue",
  },
  upload: {
    title: "Télécharger une Capture d'écran de Chat",
    description: "Téléchargez vos captures d'écran de conversation et notre IA analysera les traits de personnalité.",
    dropzone: {
      title: "Glissez et déposez vos captures d'écran ici",
      supportedFormats: "Prend en charge PNG, JPG, JPEG",
      browseButton: "Parcourir les Fichiers",
    },
    selectedFiles: "Fichiers Sélectionnés",
    buttons: {
      startAnalysis: "Commencer l'Analyse",
      clearAll: "Tout Effacer",
      analyzing: "Analyse en cours...",
    },
  },
  howItWorks: {
    title: "Comment ça Marche",
    steps: [
      {
        number: "1",
        title: "Télécharger",
        description: "Téléchargez des captures d'écran de conversations.",
      },
      {
        number: "2",
        title: "Extraction",
        description: "Notre technologie OCR extrait le texte de vos images.",
      },
      {
        number: "3",
        title: "Analyse",
        description: "L'IA avancée analyse les modèles de communication.",
      },
      {
        number: "4",
        title: "Résultats",
        description: "Obtenez des aperçus détaillés de la personnalité que vous pouvez partager.",
      },
    ],
  },
  analysis: {
    loading: {
      title: "Analyse du Chat...",
      ocrStep: "Extraction du texte des images",
      aiStep: "Analyse des traits de personnalité",
      waitMessage: "Cela peut prendre quelques instants",
    },
    placeholder: {
      title: "Votre Analyse de Personnalité Apparaîtra Ici",
      description: "Téléchargez des captures d'écran de conversation et laissez notre IA analyser les traits de personnalité dans les messages.",
      tags: [
        "Style de Communication",
        "Modèles Émotionnels",
        "Dynamiques Sociales",
        "Traits de Personnalité",
      ],
    },
    results: {
      title: "Résultats d'Analyse de Personnalité",
      sections: {
        summary: "Résumé de la Personnalité",
        traits: "Traits de Personnalité",
        communicationPatterns: "Modèles de Communication",
        strengthsAreas: "Forces et Domaines de Croissance",
        compatibilityInsights: "Aperçus de Compatibilité",
      },
      categories: {
        communicationStyle: "Style de Communication",
        decisionMaking: "Prise de Décision",
        socialApproach: "Approche Sociale",
        emotionalExpression: "Expression Émotionnelle",
      },
      strengthsTitle: "Forces",
      growthAreasTitle: "Domaines de Croissance",
      worksWellWith: "Fonctionne Bien Avec",
      challengesWith: "Peut Avoir des Défis Avec",
    },
    actions: {
      copy: "Copier les Résultats",
      download: "Télécharger en tant qu'Image",
      copiedMessage: "Résultats copiés dans le presse-papiers!",
    },
  },
  footer: {
    copyright: "© 2023 Chataro - Analyseur de Personnalité IA",
    poweredBy: "Propulsé par OCR.Space et OpenAI GPT-4",
    links: {
      privacy: "Politique de Confidentialité",
      terms: "Conditions d'Utilisation",
      contact: "Contact",
    },
  },
  errors: {
    fileFormat: "Veuillez sélectionner des fichiers image valides (PNG, JPG, JPEG).",
    ocrFailed: "Échec de l'extraction du texte des images. Veuillez réessayer.",
    analysisFailed: "Échec de l'analyse de la personnalité. Veuillez réessayer.",
    generic: "Une erreur s'est produite. Veuillez réessayer.",
  },
};

// تعريف الترجمات للغة الإسبانية
translations.es = {
  appName: "Chataro",
  header: {
    tagline: "Analizador de Personalidad IA",
    languages: {
      en: "English",
      ar: "العربية",
      fr: "Français",
      es: "Español",
      zh: "中文",
      ja: "日本語"
    },
  },
  settings: {
    switchToDark: "Cambiar al modo oscuro",
    switchToLight: "Cambiar al modo claro",
    theme: "Tema",
    language: "Idioma",
  },
  upload: {
    title: "Subir Captura de Pantalla de Chat",
    description: "Sube capturas de pantalla de tus conversaciones y nuestra IA analizará los rasgos de personalidad.",
    dropzone: {
      title: "Arrastra y suelta tus capturas de pantalla aquí",
      supportedFormats: "Soporta PNG, JPG, JPEG",
      browseButton: "Explorar Archivos",
    },
    selectedFiles: "Archivos Seleccionados",
    buttons: {
      startAnalysis: "Comenzar Análisis",
      clearAll: "Borrar Todo",
      analyzing: "Analizando...",
    },
  },
  howItWorks: {
    title: "Cómo Funciona",
    steps: [
      {
        number: "1",
        title: "Subir",
        description: "Sube capturas de pantalla de conversaciones de chat.",
      },
      {
        number: "2",
        title: "Extraer",
        description: "Nuestra tecnología OCR extrae el texto de tus imágenes.",
      },
      {
        number: "3",
        title: "Analizar",
        description: "IA avanzada analiza patrones de comunicación.",
      },
      {
        number: "4",
        title: "Resultados",
        description: "Obtén conocimientos detallados de personalidad que puedes compartir.",
      },
    ],
  },
  analysis: {
    loading: {
      title: "Analizando Chat...",
      ocrStep: "Extrayendo texto de imágenes",
      aiStep: "Analizando rasgos de personalidad",
      waitMessage: "Esto puede tomar unos momentos",
    },
    placeholder: {
      title: "Tu Análisis de Personalidad Aparecerá Aquí",
      description: "Sube capturas de pantalla de conversaciones de chat y deja que nuestra IA analice los rasgos de personalidad en los mensajes.",
      tags: [
        "Estilo de Comunicación",
        "Patrones Emocionales",
        "Dinámica Social",
        "Rasgos de Personalidad",
      ],
    },
    results: {
      title: "Resultados del Análisis de Personalidad",
      sections: {
        summary: "Resumen de Personalidad",
        traits: "Rasgos de Personalidad",
        communicationPatterns: "Patrones de Comunicación",
        strengthsAreas: "Fortalezas y Áreas de Crecimiento",
        compatibilityInsights: "Información de Compatibilidad",
      },
      categories: {
        communicationStyle: "Estilo de Comunicación",
        decisionMaking: "Toma de Decisiones",
        socialApproach: "Enfoque Social",
        emotionalExpression: "Expresión Emocional",
      },
      strengthsTitle: "Fortalezas",
      growthAreasTitle: "Áreas de Crecimiento",
      worksWellWith: "Trabaja Bien Con",
      challengesWith: "Puede Tener Desafíos Con",
    },
    actions: {
      copy: "Copiar Resultados",
      download: "Descargar como Imagen",
      copiedMessage: "¡Resultados copiados al portapapeles!",
    },
  },
  footer: {
    copyright: "© 2023 Chataro - Analizador de Personalidad IA",
    poweredBy: "Desarrollado por OCR.Space y OpenAI GPT-4",
    links: {
      privacy: "Política de Privacidad",
      terms: "Términos de Servicio",
      contact: "Contacto",
    },
  },
  errors: {
    fileFormat: "Por favor selecciona archivos de imagen válidos (PNG, JPG, JPEG).",
    ocrFailed: "Error al extraer texto de imágenes. Por favor intenta de nuevo.",
    analysisFailed: "Error al analizar la personalidad. Por favor intenta de nuevo.",
    generic: "Algo salió mal. Por favor intenta de nuevo.",
  },
};

// تعريف الترجمات للغة الصينية
translations.zh = {
  appName: "Chataro",
  header: {
    tagline: "AI 个性分析器",
    languages: {
      en: "English",
      ar: "العربية",
      fr: "Français",
      es: "Español",
      zh: "中文",
      ja: "日本語"
    },
  },
  settings: {
    switchToDark: "切换到暗模式",
    switchToLight: "切换到亮模式",
    theme: "主题",
    language: "语言",
  },
  upload: {
    title: "上传聊天截图",
    description: "上传您的聊天对话截图，我们的人工智能将分析性格特征。",
    dropzone: {
      title: "将您的聊天截图拖放到这里",
      supportedFormats: "支持PNG, JPG, JPEG",
      browseButton: "浏览文件",
    },
    selectedFiles: "已选文件",
    buttons: {
      startAnalysis: "开始分析",
      clearAll: "全部清除",
      analyzing: "分析中...",
    },
  },
  howItWorks: {
    title: "如何运作",
    steps: [
      {
        number: "1",
        title: "上传",
        description: "上传聊天对话截图。",
      },
      {
        number: "2",
        title: "提取",
        description: "我们的OCR技术从您的图像中提取文本。",
      },
      {
        number: "3",
        title: "分析",
        description: "高级AI分析沟通模式。",
      },
      {
        number: "4",
        title: "结果",
        description: "获得您可以分享的详细个性洞察。",
      },
    ],
  },
  analysis: {
    loading: {
      title: "分析聊天...",
      ocrStep: "从图像中提取文本",
      aiStep: "分析性格特征",
      waitMessage: "这可能需要一点时间",
    },
    placeholder: {
      title: "您的个性分析将显示在这里",
      description: "上传聊天对话截图，让我们的AI分析消息中的性格特征。",
      tags: [
        "沟通风格",
        "情感模式",
        "社交动态",
        "性格特征",
      ],
    },
    results: {
      title: "个性分析结果",
      sections: {
        summary: "个性摘要",
        traits: "性格特征",
        communicationPatterns: "沟通模式",
        strengthsAreas: "优势和成长领域",
        compatibilityInsights: "兼容性洞察",
      },
      categories: {
        communicationStyle: "沟通风格",
        decisionMaking: "决策方式",
        socialApproach: "社交方式",
        emotionalExpression: "情感表达",
      },
      strengthsTitle: "优势",
      growthAreasTitle: "成长领域",
      worksWellWith: "与之合作良好",
      challengesWith: "可能面临挑战的对象",
    },
    actions: {
      copy: "复制结果",
      download: "下载为图像",
      copiedMessage: "结果已复制到剪贴板！",
    },
  },
  footer: {
    copyright: "© 2023 Chataro - AI 个性分析器",
    poweredBy: "由OCR.Space和OpenAI GPT-4提供支持",
    links: {
      privacy: "隐私政策",
      terms: "服务条款",
      contact: "联系我们",
    },
  },
  errors: {
    fileFormat: "请选择有效的图像文件（PNG, JPG, JPEG）。",
    ocrFailed: "从图像中提取文本失败。请重试。",
    analysisFailed: "分析性格失败。请重试。",
    generic: "出了点问题。请重试。",
  },
};

// تعريف الترجمات للغة اليابانية
translations.ja = {
  appName: "Chataro",
  header: {
    tagline: "AI 性格分析ツール",
    languages: {
      en: "English",
      ar: "العربية",
      fr: "Français",
      es: "Español",
      zh: "中文",
      ja: "日本語"
    },
  },
  settings: {
    switchToDark: "ダークモードに切り替える",
    switchToLight: "ライトモードに切り替える",
    theme: "テーマ",
    language: "言語",
  },
  upload: {
    title: "チャットのスクリーンショットをアップロード",
    description: "会話のスクリーンショットをアップロードすると、AIが性格特性を分析します。",
    dropzone: {
      title: "チャットのスクリーンショットをここにドラッグ＆ドロップ",
      supportedFormats: "PNG、JPG、JPEGに対応",
      browseButton: "ファイルを参照",
    },
    selectedFiles: "選択されたファイル",
    buttons: {
      startAnalysis: "分析を開始",
      clearAll: "すべて消去",
      analyzing: "分析中...",
    },
  },
  howItWorks: {
    title: "仕組み",
    steps: [
      {
        number: "1",
        title: "アップロード",
        description: "チャット会話のスクリーンショットをアップロードします。",
      },
      {
        number: "2",
        title: "抽出",
        description: "OCR技術により画像からテキストを抽出します。",
      },
      {
        number: "3",
        title: "分析",
        description: "高度なAIがコミュニケーションパターンを分析します。",
      },
      {
        number: "4",
        title: "結果",
        description: "共有可能な詳細な性格分析結果を取得します。",
      },
    ],
  },
  analysis: {
    loading: {
      title: "チャットを分析中...",
      ocrStep: "画像からテキストを抽出中",
      aiStep: "性格特性を分析中",
      waitMessage: "少しお待ちください",
    },
    placeholder: {
      title: "性格分析結果がここに表示されます",
      description: "チャット会話のスクリーンショットをアップロードして、AIにメッセージ内の性格特性を分析させましょう。",
      tags: [
        "コミュニケーションスタイル",
        "感情パターン",
        "社会的ダイナミクス",
        "性格特性",
      ],
    },
    results: {
      title: "性格分析結果",
      sections: {
        summary: "性格の概要",
        traits: "性格特性",
        communicationPatterns: "コミュニケーションパターン",
        strengthsAreas: "強みと成長分野",
        compatibilityInsights: "相性の洞察",
      },
      categories: {
        communicationStyle: "コミュニケーションスタイル",
        decisionMaking: "意思決定方法",
        socialApproach: "社会的アプローチ",
        emotionalExpression: "感情表現",
      },
      strengthsTitle: "強み",
      growthAreasTitle: "成長分野",
      worksWellWith: "相性の良い相手",
      challengesWith: "課題がある相手",
    },
    actions: {
      copy: "結果をコピー",
      download: "画像としてダウンロード",
      copiedMessage: "結果がクリップボードにコピーされました！",
    },
  },
  footer: {
    copyright: "© 2023 Chataro - AI 性格分析ツール",
    poweredBy: "OCR.SpaceとOpenAI GPT-4を利用",
    links: {
      privacy: "プライバシーポリシー",
      terms: "利用規約",
      contact: "お問い合わせ",
    },
  },
  errors: {
    fileFormat: "有効な画像ファイル（PNG、JPG、JPEG）を選択してください。",
    ocrFailed: "画像からのテキスト抽出に失敗しました。再試行してください。",
    analysisFailed: "性格分析に失敗しました。再試行してください。",
    generic: "エラーが発生しました。再試行してください。",
  },
};

export const getTranslation = (lang: Language, key: string, nestedKeys?: string[]): string => {
  try {
    // Make sure the language exists
    if (!translations[lang]) {
      console.warn(`Language not found: ${lang}, falling back to English`);
      lang = 'en';
    }
    
    let translation: any = translations[lang];
    let path = key.split('.');
    
    // Handle nested keys
    for (const segment of path) {
      if (!translation || typeof translation !== 'object') {
        throw new Error(`Path segment ${segment} not found in translation object`);
      }
      translation = translation[segment];
    }
    
    // Handle further nested keys if provided
    if (nestedKeys && nestedKeys.length > 0 && typeof translation === 'object') {
      for (const nestedKey of nestedKeys) {
        if (!translation || typeof translation !== 'object') {
          throw new Error(`Nested key ${nestedKey} not found in translation object`);
        }
        translation = translation[nestedKey];
      }
    }
    
    if (translation === undefined) {
      throw new Error(`Translation missing for key: ${key} in language: ${lang}`);
    }
    
    // For string values
    if (typeof translation === 'string') {
      return translation;
    }
    
    // For array values, we'll return them as is and handle conversion elsewhere
    if (Array.isArray(translation)) {
      return translation as any;
    }
    
    // For unexpected object values
    return key;
  } catch (error) {
    console.error(`Translation error: ${error}`);
    
    // Fallback to English
    if (lang !== 'en') {
      return getTranslation('en', key, nestedKeys);
    }
    
    return key;
  }
};

export const getDirection = (lang: Language): 'ltr' | 'rtl' => {
  return lang === 'ar' ? 'rtl' : 'ltr';
};

export default { getTranslation, getDirection };
