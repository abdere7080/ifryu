# Chataro AI - Personality Analysis Chat App

## Overview

Chataro AI is a web application that analyzes personality traits from chat screenshots using OCR and AI. Users can upload images of their chat conversations, and the system extracts text using OCR.Space API and performs personality analysis using Google's Gemini AI or Groq as a backup. The app supports multiple languages and provides detailed personality insights with visualizations.

## User Preferences

```
Preferred communication style: Simple, everyday language.
```

## System Architecture

### Full-Stack Architecture
- **Frontend**: React with TypeScript, Vite build tool
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL via Neon serverless
- **ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: Passport.js with Google OAuth strategy
- **Deployment**: Built for production with ESBuild

### Key Design Decisions
- **Monorepo Structure**: Client, server, and shared code in one repository
- **TypeScript Throughout**: Type safety across frontend, backend, and shared schemas
- **Serverless Database**: Neon PostgreSQL for scalability and ease of deployment
- **Modern UI**: Shadcn/ui components with Tailwind CSS for consistent design
- **Multi-language Support**: Built-in internationalization with RTL support

## Key Components

### Frontend Architecture
- **React with TypeScript**: Component-based UI development
- **Vite**: Fast development server and build tool
- **TanStack Query**: Server state management and caching
- **Wouter**: Lightweight routing solution
- **Tailwind CSS**: Utility-first styling framework
- **Shadcn/ui**: Pre-built component library

### Backend Architecture
- **Express.js**: RESTful API server
- **Passport.js**: Authentication middleware with Google OAuth
- **Drizzle ORM**: Database operations with type safety
- **Session Management**: PostgreSQL-based session storage
- **File Upload**: Multer for handling image uploads

### Database Schema
- **Users Table**: Stores user information with OAuth support
- **Analyses Table**: Stores personality analysis results
- **Sessions Table**: Manages user sessions
- **Passwords Table**: Optional local authentication support

## Data Flow

1. **Image Upload**: Users upload chat screenshots via drag-and-drop interface
2. **OCR Processing**: Images are sent to OCR.Space API to extract text
3. **AI Analysis**: Extracted text is processed by Google Gemini or Groq AI
4. **Result Storage**: Analysis results are stored in PostgreSQL database
5. **Visualization**: Results are displayed with interactive charts and insights

### Authentication Flow
1. User initiates Google OAuth login
2. Passport.js handles OAuth flow with Google
3. User information is stored/retrieved from database
4. Session is maintained with PostgreSQL session store

## External Dependencies

### Third-Party Services
- **OCR.Space API**: Text extraction from images
- **Google Gemini AI**: Primary AI service for personality analysis
- **Groq AI**: Backup AI service for analysis
- **Google OAuth**: User authentication

### Key Libraries
- **@neondatabase/serverless**: Database connection
- **@google/generative-ai**: Gemini AI integration
- **groq-sdk**: Groq AI integration
- **passport-google-oauth20**: Google authentication
- **multer**: File upload handling
- **bcrypt**: Password hashing (for local auth)

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds React app to `dist/public`
- **Backend**: ESBuild compiles TypeScript server to `dist/index.js`
- **Database**: Drizzle migrations handle schema changes

### Production Configuration
- **Environment Variables**: Required for database, OAuth, and API keys
- **Session Storage**: PostgreSQL-backed sessions for scalability
- **Static Assets**: Served from built frontend directory

### Development vs Production
- **Development**: Vite dev server with HMR, TypeScript checking
- **Production**: Compiled JavaScript with optimized assets
- **Database**: Same Neon PostgreSQL for both environments

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `GOOGLE_CLIENT_ID`: Google OAuth client ID
- `GOOGLE_CLIENT_SECRET`: Google OAuth client secret
- `GEMINI_API_KEY`: Google Gemini API key
- `GROQ_API_KEY`: Groq API key (optional backup)
- `OCR_API_KEY`: OCR.Space API key
- `SESSION_SECRET`: Session encryption secret