import { pgTable, text, serial, integer, jsonb, timestamp, boolean, varchar, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - needed for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Enhanced users table with support for Google Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey(), // Using string ID for OAuth compatibility
  email: varchar("email", { length: 255 }).notNull().unique(),
  username: varchar("username", { length: 100 }).unique(),
  name: varchar("name", { length: 255 }),
  profileImageUrl: varchar("profile_image_url"),
  provider: varchar("provider", { length: 20 }).notNull().default("local"), // google, local, etc.
  emailVerified: boolean("email_verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Optional password table for local authentication
export const passwords = pgTable("passwords", {
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  hash: varchar("hash", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  id: true,
  email: true, 
  username: true,
  name: true,
  profileImageUrl: true,
  provider: true,
  emailVerified: true
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const insertPasswordSchema = createInsertSchema(passwords);
export type InsertPassword = z.infer<typeof insertPasswordSchema>;
export type Password = typeof passwords.$inferSelect;

// Schema for analysis results
export const analyses = pgTable("analyses", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id), // Updated to varchar to match users.id
  extractedText: text("extracted_text").notNull(),
  result: jsonb("result").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAnalysisSchema = createInsertSchema(analyses).omit({
  id: true,
  createdAt: true,
});

export type InsertAnalysis = z.infer<typeof insertAnalysisSchema>;
export type Analysis = typeof analyses.$inferSelect;

// Personality trait structure
export interface Trait {
  name: string;
  value: number;
  color: string;
}

// Interface for the analysis results from the GPT model
export interface PersonalityAnalysis {
  summary: string;
  communicationStyle: string;
  decisionMaking: string;
  socialApproach: string;
  emotionalExpression: string;
  traits: Trait[];
  communicationPatterns: {
    title: string;
    description: string;
  }[];
  strengths: string[];
  growthAreas: string[];
  compatibilityInsights: string;
  worksWellWith: string[];
  challengesWith: string[];
}

// Input schema for image upload
export const imageUploadSchema = z.object({
  images: z.array(
    z.string().refine((val) => val.startsWith("data:image/"), {
      message: "File must be an image",
    })
  ),
});

export type ImageUpload = z.infer<typeof imageUploadSchema>;
